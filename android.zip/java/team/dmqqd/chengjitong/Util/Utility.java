package team.dmqqd.chengjitong.Util;

import com.google.gson.Gson;

import team.dmqqd.chengjitong.gson.Class;
import team.dmqqd.chengjitong.gson.Person;

public class Utility {

    public static Person handlePersonResponse(String jsondata) {
        return new Gson().fromJson(jsondata, Person.class);
    }


    public static Class handleClassResponse(String jsondata) {
        return new Gson().fromJson(jsondata,Class.class);
    }

}