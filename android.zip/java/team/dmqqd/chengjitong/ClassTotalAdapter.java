package team.dmqqd.chengjitong;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import team.dmqqd.chengjitong.gson.Person;

public class ClassTotalAdapter extends RecyclerView.Adapter<team.dmqqd.chengjitong.ClassTotalAdapter.ViewHolder> {

        private static final String TAG = "ClassTotalAdapter";

        private Context mContext;

        private int mTerm;

        private List<Person> mPersonList;

        static class ViewHolder extends RecyclerView.ViewHolder {
            CardView cardView;
            TextView rankView;
            TextView nameView;
            TextView scoreView;

            public ViewHolder(View view) {
                super(view);
                cardView = (CardView) view;
                rankView = view.findViewById(R.id.class_total_rank);
                nameView = view.findViewById(R.id.class_total_name);
                scoreView  = view.findViewById(R.id.class_total_score);
            }
        }

        public ClassTotalAdapter(List<Person> personList,int term) {
            this.mPersonList = personList;
            this.mTerm = term;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (mContext == null) {
                mContext = parent.getContext();
            }
            View view = LayoutInflater.from(mContext).inflate(R.layout.class_total_item, parent, false);
            final ViewHolder holder = new ViewHolder(view);
            return holder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Person person = mPersonList.get(position);
            String name = person.getName();
            Person.ScoresListBean scoresListBean = person.getScoresList().get(mTerm);
            int rank = scoresListBean.getNO();
            int score = scoresListBean.getTotle_score();
            holder.rankView.setText(rank);
            holder.nameView.setText(name);
            holder.scoreView.setText(score);
        }

        @Override
        public int getItemCount() {
            return mPersonList.size();
        }

    }

