package team.dmqqd.chengjitong;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import team.dmqqd.chengjitong.Util.Utility;
import team.dmqqd.chengjitong.gson.Class;
import team.dmqqd.chengjitong.gson.Person;

public class ClassTotalActivity extends AppCompatActivity {

    private ClassTotalAdapter adapter;
    private Class mClass;
    private int mTerm;
    private List<Person> classTotalList = new ArrayList<>();//获取Class数据

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_total);
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        initList();
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.class_total_recycler);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new ClassTotalAdapter(classTotalList, mTerm);
        recyclerView.setAdapter(adapter);
    }

    private void initList() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String classData = prefs.getString("class", null);
        mTerm = getIntent().getIntExtra("term",-1);
        mClass = Utility.handleClassResponse(classData);
        classTotalList = mClass.getStuScores();
        Collections.sort(classTotalList, new Comparator<Person>() {
            @Override
            public int compare(Person person, Person t1) {
                int curNo = person.getScoresList().get(mTerm).getNO();
                int nextNo = t1.getScoresList().get(mTerm).getNO();

                if(curNo > nextNo){
                    return 1;
                }else if(curNo < nextNo){
                    return -1;
                }else {
                    return 0;
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
    //还有个雷达图

