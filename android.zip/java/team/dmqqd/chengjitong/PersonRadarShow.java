package team.dmqqd.chengjitong;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;

import java.util.List;
import java.util.Map;

import team.dmqqd.chengjitong.Util.Utility;
import team.dmqqd.chengjitong.View.RadarView;
import team.dmqqd.chengjitong.gson.Person;

public class PersonRadarShow extends AppCompatActivity {
    RadarView radarView;
    private String[] mText = new String[6];
    private float[] mData = new float[6];
    private int index = 0;
    private int mTerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_radar_show);
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        String personData = getIntent().getStringExtra("person");
        mTerm = getIntent().getIntExtra("term",-1);
        Person person = Utility.handlePersonResponse(personData);
        Map<String,Integer> subjMap = person.getScoresList().get(mTerm).getSubjMap();
        for(String key:subjMap.keySet()){
            mText[index] = key;
            mData[index] = subjMap.get(key);
        }
        radarView.setData(mData,mText);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
