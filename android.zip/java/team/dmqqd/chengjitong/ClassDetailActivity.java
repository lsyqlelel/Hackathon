package team.dmqqd.chengjitong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import team.dmqqd.chengjitong.Util.Utility;
import team.dmqqd.chengjitong.gson.Person;
import team.dmqqd.chengjitong.gson.Class;

public class ClassDetailActivity extends AppCompatActivity {

    private ClassDetailAdapter adapter;
    private Class mClass;
    private String mSubject;
    TextView textView_subject;
    TextView textView_excellentRate;
    TextView textView_passRate;
    TextView textView_max;
    TextView textView_min;
    TextView textView_aver;

    private List<Class.SubjectRank> subjectRankList = new ArrayList<>();//获取Class数据

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_detail);
        initView();
        setViewData();
        initList();
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.class_detail_recycler);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new ClassDetailAdapter(subjectRankList);
        recyclerView.setAdapter(adapter);
    }

    private void initView(){
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        textView_subject = findViewById(R.id.class_detail_subject_name);
        textView_excellentRate = findViewById(R.id.class_detail_excellentRate_number);
        textView_passRate = findViewById(R.id.class_detail_passRate_num);
        textView_max = findViewById(R.id.class_detail_max_number);
        textView_min = findViewById(R.id.class_detail_min_number);
        textView_aver = findViewById(R.id.class_detail_aver_number);
    }

    private void setViewData(){
        Intent intent = getIntent();

        mSubject = intent.getStringExtra("subject");
        double excellentRate = intent.getDoubleExtra("excellentRate",-1);
        double passRate = intent.getDoubleExtra("passRate",-1);
        int max = intent.getIntExtra("max",-1);
        int min = intent.getIntExtra("min",-1);
        double aver = intent.getDoubleExtra("aver",-1);

        NumberFormat num = NumberFormat.getPercentInstance();
        num.setMaximumFractionDigits(2);//percent格式化

        DecimalFormat df = new DecimalFormat("#.00");//aver格式化

        textView_subject.setText(mSubject);
        textView_excellentRate.setText(num.format(excellentRate));
        textView_passRate.setText(num.format(passRate));
        textView_max.setText(max + "");
        textView_min.setText(min + "");
        textView_aver.setText(df.format(aver));

    }
    private void initList(){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String classData = prefs.getString("class", null);
        mClass = Utility.handleClassResponse(classData);

        Map<String,List<Class.SubjectRank>> subjectRankMap = mClass.getSubjRank();
        subjectRankList = subjectRankMap.get(mSubject);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
