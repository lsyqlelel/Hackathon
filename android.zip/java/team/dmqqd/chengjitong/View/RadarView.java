package team.dmqqd.chengjitong.View;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;

public class RadarView extends View {

    private Paint mPaint = new Paint();
    private TextPaint tPaint = new TextPaint();

    private String[] mText = new String[6];
    private float[] mData = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};

    //外边颜色
    private final int OUT_BORDER_COLOR = Color.parseColor("#919AA4");
    //内边颜色
    private final int IN_BORDER_COLOR = Color.parseColor("#E0E0E0");
    //数字文字颜色
    private final int TEXT_NUMBER_COLOR = Color.parseColor("#647D91");
    //汉字文字颜色
    private final int TEXT_COLOR = Color.parseColor("#3B454E");
    //填充颜色
    private final int FILL_COLOR = Color.parseColor("#CED6DC");

    //文字与图的间距
    private final int SPACE = 18;
    public RadarView(Context context) {
        this(context, null);
    }

    public RadarView(Context context, AttributeSet attrs) {
        super(context, attrs);

        init();
    }

    private void init() {
        mPaint.setStyle(Paint.Style.STROKE);

        tPaint.setTextSize(40f);
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int maxRound = (int) (Math.min(getWidth(), getHeight()) / 2 * 0.75);

        //绘制蜘蛛网
        canvas.save();

        canvas.translate(getWidth() / 2, getHeight() / 2);

        for(int i = 0; i < 6; i++) {

            mPaint.setColor(IN_BORDER_COLOR);
            mPaint.setStrokeWidth(2f);
            canvas.drawLine(0, 0, maxRound, 0, mPaint);

            for(int j = 3; j >= 1; j--) {
                canvas.drawLine((float)(maxRound * j / 4.0), 0, (float)(maxRound / 2.0 * j / 4.0), (float)(maxRound * Math.sqrt(3) / 2 * j / 4.0), mPaint);
            }

            mPaint.setColor(OUT_BORDER_COLOR);
            mPaint.setStrokeWidth(4f);
            canvas.drawLine(maxRound, 0, maxRound/2, (float) (-Math.sqrt(3)/2*maxRound-0.5), mPaint);

            canvas.rotate(60);
        }

        canvas.restore();

        //绘制文字
        canvas.save();

        canvas.translate(getWidth() / 2, getHeight() / 2);

        tPaint.setColor(TEXT_COLOR);
        canvas.drawText(mText[0], maxRound + SPACE, 0, tPaint);
        tPaint.setColor(TEXT_NUMBER_COLOR);
        canvas.drawText(mData[0] + "", maxRound + SPACE, tPaint.getTextSize() + SPACE / 4, tPaint);

        tPaint.setColor(TEXT_COLOR);
        canvas.drawText(mText[1], maxRound / 2 + SPACE, (float) (maxRound * Math.sqrt(3) / 2), tPaint);
        tPaint.setColor(TEXT_NUMBER_COLOR);
        canvas.drawText(mData[1] + "", maxRound / 2 + SPACE, (float) (maxRound * Math.sqrt(3) / 2 + tPaint.getTextSize() + SPACE / 4), tPaint);

        tPaint.setColor(TEXT_COLOR);
        canvas.drawText(mText[2], -maxRound / 2 - SPACE - tPaint.getTextSize() * 2, (float) (maxRound * Math.sqrt(3) / 2), tPaint);
        tPaint.setColor(TEXT_NUMBER_COLOR);
        canvas.drawText(mData[2] + "", -maxRound / 2 - SPACE - tPaint.getTextSize() * 2, (float) (maxRound * Math.sqrt(3) / 2 + tPaint.getTextSize() + SPACE / 4), tPaint);

        tPaint.setColor(TEXT_COLOR);
        canvas.drawText(mText[3], -maxRound - SPACE - tPaint.getTextSize() * 2, 0, tPaint);
        tPaint.setColor(TEXT_NUMBER_COLOR);
        canvas.drawText(mData[3] + "", -maxRound - SPACE - tPaint.getTextSize() * 2,  tPaint.getTextSize() + SPACE / 4, tPaint);

        tPaint.setColor(TEXT_COLOR);
        canvas.drawText(mText[4], -maxRound / 2 - SPACE * 2 - tPaint.getTextSize() * 2, -(float) (maxRound * Math.sqrt(3) / 2), tPaint);
        tPaint.setColor(TEXT_NUMBER_COLOR);
        canvas.drawText(mData[4] + "", -maxRound / 2 - SPACE * 2 - tPaint.getTextSize() * 2, -(float) (maxRound * Math.sqrt(3) / 2 - tPaint.getTextSize() + SPACE / 4), tPaint);

        tPaint.setColor(TEXT_COLOR);
        canvas.drawText(mText[5], maxRound / 2 + SPACE * 2, -(float) (maxRound * Math.sqrt(3) / 2), tPaint);
        tPaint.setColor(TEXT_NUMBER_COLOR);
        canvas.drawText(mData[5] + "", maxRound / 2 + SPACE * 2, -(float) (maxRound * Math.sqrt(3) / 2 - tPaint.getTextSize() + SPACE / 4), tPaint);
        canvas.restore();

        //绘制内容区域
        canvas.save();

        canvas.translate(getWidth() / 2, getHeight() / 2);

        Paint paint = new Paint();
        paint.setColor(FILL_COLOR);
        paint.setAlpha(0x88);
        paint.setStyle(Paint.Style.FILL);

        Path path = new Path();
        path.moveTo(mData[0] / 100 * maxRound, 0f);
        path.lineTo(mData[1] / 100 / 2 * maxRound, (float) (mData[1] / 100 * Math.sqrt(3) / 2 * maxRound));
        path.lineTo(-mData[2] / 100 / 2 * maxRound, (float) (mData[2] / 100 * Math.sqrt(3) / 2 * maxRound));
        path.lineTo(-mData[3] / 100 * maxRound, 0f);
        path.lineTo(-mData[4] / 100 / 2 * maxRound, (float) (-mData[4] / 100 * Math.sqrt(3) / 2 * maxRound));
        path.lineTo(mData[5] / 100 / 2 * maxRound, (float) (-mData[5] / 100 * Math.sqrt(3) / 2 * maxRound));

        path.close();

        canvas.drawPath(path, paint);

        canvas.restore();

    }

    //设置数据，需要在ui线程中调用
    public void setData(float[] data,String[] text) {
        if(6 != data.length || 6 != text.length) {
            return;
        }
        this.mText = text;
        this.mData = data;
        invalidate();
    }
}
