package team.dmqqd.chengjitong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import team.dmqqd.chengjitong.Util.HttpUtil;
import team.dmqqd.chengjitong.Util.Utility;
import team.dmqqd.chengjitong.gson.Person;
import team.dmqqd.chengjitong.gson.SubjectPerson;

public class PersonActivity extends AppCompatActivity {
    public static final String PATH = "chengjitong/";
    private List<SubjectPerson> mSubjects = new ArrayList<>();//获取界面1所需要的数据
    private String mNumber;
    private int mTerm;
    private Person mPerson;
    private String mJsonData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person);
        Button button = (Button) findViewById(R.id.person_total);
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.person_recycler);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        PersonAdapter adapter = new PersonAdapter(mSubjects);
        recyclerView.setAdapter(adapter);

        mTerm = getIntent().getIntExtra("term", -1);
        mNumber = getIntent().getStringExtra("number");
        requestPerson(mNumber);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mPerson != null) {
                    Intent intent = new Intent(PersonActivity.this, PersonTotalActivity.class);
                    intent.putExtra("person", mJsonData);
                    intent.putExtra("term", mTerm);
                    startActivity(intent);
                }
            }
        });
    }

    public void requestPerson(final String number) {
        String personUrl = PATH + number;
        HttpUtil.sendOkHttpRequest(personUrl, new Callback() {
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                mJsonData = response.body().string();//包含了person类的json信息
                mPerson = Utility.handlePersonResponse(mJsonData);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mPerson != null) {
                            //存入SharedPreferences，可以在其他的活动中获得person对应的json
                            SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(PersonActivity.this).edit();
                            editor.putString("person", mJsonData);
                            editor.apply();
                            getListData();
                        } else {
                            Toast.makeText(PersonActivity.this, "获取个人信息失败", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }

            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(PersonActivity.this, "获取个人信息失败", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void getListData() {
        if (mTerm != -1) {
            Person.ScoresListBean scoresListBean = mPerson.getScoresList().get(mTerm);
            Map<String, Integer> subjMap = scoresListBean.getSubjMap();
            for (String key : subjMap.keySet()) {
                SubjectPerson subjectPerson = new SubjectPerson(key, subjMap.get(key));
                mSubjects.add(subjectPerson);
            }
        } else {
            Toast.makeText(PersonActivity.this, "获取学期信息失败", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
