package team.dmqqd.chengjitong;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import team.dmqqd.chengjitong.gson.Class;

public class ClassAdapter extends RecyclerView.Adapter<ClassAdapter.ViewHolder> {

    private static final String TAG = "ClassAdapter";

    private Context mContext;

    private List<Class.Subject> mSubjects;

    static class ViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        ImageView imageView;
        TextView subjectView;

        public ViewHolder(View view) {
            super(view);
            cardView = (CardView) view;
            imageView = view.findViewById(R.id.class_sketchy_icon);
            subjectView = view.findViewById(R.id.class_sketchy_subject);
        }
    }

    public ClassAdapter(List<Class.Subject> subjects) {
        this.mSubjects = subjects;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (mContext == null) {
            mContext = parent.getContext();
        }
        View view = LayoutInflater.from(mContext).inflate(R.layout.class_item, parent, false);
        final ViewHolder holder = new ViewHolder(view);
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = holder.getAdapterPosition();
                Class.Subject subjectClass = mSubjects.get(position);
                String subject = subjectClass.getSubj();
                double excellentRate = subjectClass.getExcellentRate();
                double passRate = subjectClass.getPassRate();
                int max = subjectClass.getMax();
                int min = subjectClass.getMin();
                double aver = subjectClass.getAver();

                Intent intent = new Intent(mContext,ClassDetailActivity.class);
                intent.putExtra("subject",subject);
                intent.putExtra("excellentRate",excellentRate);
                intent.putExtra("passRate",passRate);
                intent.putExtra("max",max);
                intent.putExtra("min",min);
                intent.putExtra("aver",aver);

                mContext.startActivity(intent);
            }
        });
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Class.Subject subject= mSubjects.get(position);
        String subjectName = subject.getSubj();
        holder.subjectView.setText(subjectName);
    }

    @Override
    public int getItemCount() {
        return mSubjects.size();
    }

}