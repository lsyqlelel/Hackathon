package team.dmqqd.chengjitong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    private CardView cardView_mine;
    private CardView cardView_class;
    private Button button;
    private String isMonitor;
    private String number;
    public static final int OPEN_MINE = 0;
    public static final int OPEN_CLASS = 1;
    private static final String TAG = "MainActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        isMonitor = intent.getStringExtra("isMonitor");
        number = intent.getStringExtra("number");
        Log.d(TAG,isMonitor);

        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(this).edit();
        editor.putString("account", number);
        editor.apply();

        initView();
    }

    private void initView() {
        cardView_mine = findViewById(R.id.cardview_mine);
        cardView_mine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseTerm(OPEN_MINE);
            }
        });
        cardView_class = findViewById(R.id.cardview_class);
        cardView_class.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseTerm(OPEN_CLASS);
            }
        });
        button = (Button)findViewById(R.id.back);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
       if(isMonitor.equals("0")){//空指针+闪退+init要放在isMonitor后啊！！！！！！！！！！！！！！！！
            cardView_class.setVisibility(View.GONE);
        }

    }
    private void chooseTerm(int openCode){
        Intent intent = new Intent(this,ChsTermActivity.class);
        intent.putExtra("code",openCode);
        if(openCode == OPEN_MINE){
            intent.putExtra("number",number);
        }
        startActivity(intent);
    }
}
//加个退出登录的按钮