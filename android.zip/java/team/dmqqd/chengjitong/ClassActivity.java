package team.dmqqd.chengjitong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import team.dmqqd.chengjitong.Util.HttpUtil;
import team.dmqqd.chengjitong.Util.Utility;
import team.dmqqd.chengjitong.gson.Class;

import static team.dmqqd.chengjitong.PersonActivity.PATH;

public class ClassActivity extends AppCompatActivity {

    private ClassAdapter adapter;
    private List<Class.Subject> mSubjects = new ArrayList<>();//获取Class数据
    private Button button;
    private Class mClass;
    private int mTerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class);
        button = (Button)findViewById(R.id.class_total);
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.class_recycler);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new ClassAdapter(mSubjects);//初始化列表要提前
        recyclerView.setAdapter(adapter);

        mTerm = getIntent().getIntExtra("term",-1);
        requestClass(mTerm);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ClassActivity.this,ClassTotalActivity.class);
                intent.putExtra("term",mTerm);
                startActivity(intent);
            }
        });
    }

    public void requestClass(int term){
        String personUrl = PATH  + "1";
        HttpUtil.sendOkHttpRequest(personUrl,new Callback(){
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseData = response.body().string();
                mClass = Utility.handleClassResponse(responseData);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mClass != null) {
                            SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(ClassActivity.this).edit();
                            editor.putString("class", responseData);
                            editor.apply();
                            getListData();
                        } else {
                            Toast.makeText(ClassActivity.this, "获取班级信息失败", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(ClassActivity.this, "获取班级信息失败", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void getListData() {
        for(int i=mTerm * 6;i<mTerm * 6 + 6;i++){
            Class.Subject subject = mClass.getBasicDate().get(i);
            mSubjects.add(subject);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
