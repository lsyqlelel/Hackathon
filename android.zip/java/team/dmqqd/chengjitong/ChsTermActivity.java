package team.dmqqd.chengjitong;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class ChsTermActivity extends AppCompatActivity {

    private TermAdapter adapter;
    private int openCode;
    private String number;
    private List<String> mTermList = new ArrayList<>();//需要获取学期数据

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chs_term);
        Intent intent = getIntent();
        number = intent.getStringExtra("number");
        openCode = intent.getIntExtra("code",-1);
        initList();
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.term_recycler);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new TermAdapter(mTermList,openCode,number);
        recyclerView.setAdapter(adapter);
    }

    private void initList(){
        mTermList.add("大一上");
        mTermList.add("大一下");
        mTermList.add("大二上");
        mTermList.add("大二下");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
