package team.dmqqd.chengjitong;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import javax.security.auth.Subject;

import team.dmqqd.chengjitong.gson.SubjectPerson;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.ViewHolder> {

    private static final String TAG = "PersonAdapter";

    private Context mContext;

    private List<SubjectPerson> mSubjects;

    static class ViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        ImageView imageView;
        TextView subjectView;
        TextView scoreView;

        public ViewHolder(View view) {
            super(view);
            cardView = (CardView) view;
            imageView = view.findViewById(R.id.person_sketchy_icon);
            subjectView = view.findViewById(R.id.person_sketchy_subject);
            scoreView = view.findViewById(R.id.person_sketchy_score);
        }
    }

    public PersonAdapter(List<SubjectPerson> mSubjects) {
        this.mSubjects = mSubjects;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (mContext == null) {
            mContext = parent.getContext();
        }
        View view = LayoutInflater.from(mContext).inflate(R.layout.person_item, parent, false);
        final ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        SubjectPerson subjectPerson = mSubjects.get(position);
        String subject = subjectPerson.getSubject();
        int score = subjectPerson.getScore();
        holder.subjectView.setText(subject);
        holder.scoreView.setText(score + "");
    }

    @Override
    public int getItemCount() {
        return mSubjects.size();
    }

}