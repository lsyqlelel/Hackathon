package team.dmqqd.chengjitong;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.github.mikephil.charting.charts.RadarChart;
import team.dmqqd.chengjitong.Util.Utility;
import team.dmqqd.chengjitong.View.linechartview.ChartPoint;
import team.dmqqd.chengjitong.View.linechartview.LineChartView;
import team.dmqqd.chengjitong.gson.Person;

public class PersonTotalActivity extends AppCompatActivity {
    private String mPersonJSON;
    private Person mPerson;
    private int mTerm;
    LineChartView chartView;
    TextView lineView;

    Button btn;
    TextView textView_score;
    TextView textView_aver;
    TextView textView_rank;
    TextView textView_rank_percent;

    /*private List<String> xAxisValue = new ArrayList<>();//X轴数据源
    private RadarChart radarChart;//雷达图*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_total);
        initView();

        mTerm = getIntent().getIntExtra("term",-1);
        mPersonJSON = getIntent().getStringExtra("person");

        setTextViewData();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PersonTotalActivity.this,PersonRadarShow.class);
                intent.putExtra("person",mPersonJSON);
                intent.putExtra("term",mTerm);
                startActivity(intent);
            }
        });

        initLine();
    }

    private void initView(){
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        btn = (Button) findViewById(R.id.person_detail_button);

        chartView = (LineChartView) findViewById(R.id.chartView);
        lineView = (TextView)findViewById(R.id.person_total_line_text);

        textView_score = (TextView) findViewById(R.id.person_total_score_number);
        textView_aver = (TextView) findViewById(R.id.person_total_aver_number);
        textView_rank = (TextView) findViewById(R.id.person_total_rank_num);
        textView_rank_percent = (TextView) findViewById(R.id.person_total_percent_number);
    }

    private void setTextViewData(){
        mPerson = Utility.handlePersonResponse(mPersonJSON);
        Person.ScoresListBean scoresListBean = mPerson.getScoresList().get(mTerm);

        double aver = scoresListBean.getAver();
        int rank = scoresListBean.getNO();
        double percent = scoresListBean.getRate();
        int total_score = scoresListBean.getTotle_score();//获取原始数据

        NumberFormat num = NumberFormat.getPercentInstance();
        num.setMaximumFractionDigits(2);//percent格式化

        DecimalFormat df = new DecimalFormat("#.00");//aver格式化

        textView_score.setText(total_score);
        textView_aver.setText(df.format(aver));
        textView_rank.setText(rank);
        textView_rank_percent.setText(num.format(percent));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }



    private void initLine(){
        List<Integer> xList = new ArrayList<>();
        List<Integer> yList = new ArrayList<>();
        for (int i = 0; i < mTerm + 1; i++) {
            xList.add(i + 1);
            int y = mPerson.getScoresList().get(i).getNO();
            yList.add(y);
        }
        chartView.setDataList(xList, yList);
        chartView.setOnPointClickListener(new LineChartView.OnPointClickListener() {
            @Override
            public void onPointClick(int position, ChartPoint point) {
                lineView.setText("position:" + position + "\n学期:" + point.getxData() + "\n成绩:" + point.getyData());
            }
        });
    }
}
