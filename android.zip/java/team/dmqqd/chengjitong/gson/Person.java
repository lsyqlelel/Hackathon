package team.dmqqd.chengjitong.gson;

import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Map;

public class Person {

    /**
     * id : 031799102
     * name : 张二
     * ScoresList : [{"aver":73.66666666666667,"nO":30,"rate":0.5172413793103449,"subjMap":{"计算机学科导论":75,"高等数学B（上）":74,"高级语言程序设计":95,"认知实习":98,"线性代数":52,"高级语言程序设计实践":48},"totle_score":442},{"aver":64.33333333333333,"nO":43,"rate":0.7413793103448276,"subjMap":{"面向对象程序设计":68,"大学物理A（上）":58,"高等数学B（下）":67,"基础电路与电子学":58,"电子线路综合实验":69,"大学物理实验A（上）":66},"totle_score":386},{"aver":76.16666666666667,"nO":24,"rate":0.41379310344827586,"subjMap":{"大学物理实验A（下）":86,"离散数学":96,"数字电路与逻辑设计":45,"大学物理A（下）":44,"数字逻辑电路设计实验":89,"算法与数据结构":97},"totle_score":457},{"aver":83,"nO":5,"rate":0.08620689655172414,"subjMap":{"马克思主义基本原理":99,"概率论与数理统计":63,"计算机组成原理实践":83,"计算机组成原理A":74,"汇编语言程序设计":99,"计算机网络":80},"totle_score":498}]
     */


    private String id;
    private String name;
    private List<ScoresListBean> ScoresList;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id= id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ScoresListBean> getScoresList() {
        return ScoresList;
    }

    public void setScoresList(List<ScoresListBean> ScoresList) {
        this.ScoresList = ScoresList;
    }

    public static class ScoresListBean {
        /**
         * aver : 73.66666666666667
         * nO : 30
         * rate : 0.5172413793103449
         * subjMap : {"计算机学科导论":75,"高等数学B（上）":74,"高级语言程序设计":95,"认知实习":98,"线性代数":52,"高级语言程序设计实践":48}
         * totle_score : 442
         */

        private double aver;
        private int nO;
        private double rate;
        private Map<String,Integer> subjMap;
        private int totle_score;

        public double getAver() {
            return aver;
        }

        public void setAver(double aver) {
            this.aver = aver;
        }

        public int getNO() {
            return nO;
        }

        public void setNO(int nO) {
            this.nO = nO;
        }

        public double getRate() {
            return rate;
        }

        public void setRate(double rate) {
            this.rate = rate;
        }

        public Map<String, Integer> getSubjMap() {
            return subjMap;
        }

        public void setSubjMap(Map<String, Integer> subjMap) {
            this.subjMap = subjMap;
        }

        public int getTotle_score() {
            return totle_score;
        }

        public void setTotle_score(int totle_score) {
            this.totle_score = totle_score;
        }
    }
}