package team.dmqqd.chengjitong.gson;

import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;

import javax.security.auth.Subject;

public class Class {
    //列表名要改，生成getter、setter
    private List<Person> StuScores;

    public List<Person> getStuScores() {
        return StuScores;
    }

    public void setStuScores(List<Person> stuScores) {
        StuScores = stuScores;
    }

    public List<Subject> getBasicDate() {
        return BasicDate;
    }

    public void setBasicDate(List<Subject> basicDate) {
        BasicDate = basicDate;
    }

    public Map<String, List<SubjectRank>> getSubjRank() {
        return SubjRank;
    }

    public void setSubjRank(Map<String, List<SubjectRank>> subjRank) {
        SubjRank = subjRank;
    }

    private List<Subject> BasicDate;
    private Map<String,List<SubjectRank>> SubjRank;

    public static class SubjectRank{
        private String id;
        private int nO;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public int getNO() {
            return nO;
        }

        public void setNO(int nO) {
            this.nO = nO;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getRank() {
            return rank;
        }

        public void setRank(int rank) {
            this.rank = rank;
        }

        public int getScore() {
            return score;
        }

        public void setScore(int score) {
            this.score = score;
        }

        public String getSubject() {
            return subject;
        }

        public void setSubject(String subject) {
            this.subject = subject;
        }

        private String name;
        private int rank;
        private int score;
        private String subject;
    }

    public static class Subject{
        public double getAver() {
            return aver;
        }

        public void setAver(double aver) {
            this.aver = aver;
        }

        public double getExcellentRate() {
            return excellentRate;
        }

        public void setExcellentRate(double excellentRate) {
            this.excellentRate = excellentRate;
        }

        public int getMax() {
            return max;
        }

        public void setMax(int max) {
            this.max = max;
        }

        public int getMin() {
            return min;
        }

        public void setMin(int min) {
            this.min = min;
        }

        public double getPassRate() {
            return passRate;
        }

        public void setPassRate(double passRate) {
            this.passRate = passRate;
        }

        public String getSubj() {
            return subj;
        }

        public void setSubj(String subj) {
            this.subj = subj;
        }

        private double aver;
        private double excellentRate;
        private int max;
        private int min;
        private double passRate;
        private String subj;
    }
}

