package com.Lia.app;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.Lia.Dao.MyDao;
import com.Lia.myEntity.MyClass;
import com.Lia.myEntity.Student;
import com.alibaba.fastjson.JSONObject;



//@WebServlet(asyncSupported = true, urlPatterns = { "/some" })
public class MyServlet extends HttpServlet {
	
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//设置编码
		resp.setContentType("text/html;charset=UTF-8");
		
		
		PrintWriter out=resp.getWriter();
		out.println("<h1>this is a post request </h1>");
		out.println("<h2>postpostpost<h2>");
		
		System.out.println("90909090909");
		String username = req.getParameter("username");
		System.out.println("这里是：===="+username);
		String password = req.getParameter("password");
		out.println("username :"+username);
		out.println("password :"+password);

		MyDao md = new MyDao();
		Student dateOfStud = md.getDateOfStud(username);
		JSONObject aStudent = new JSONObject();
		aStudent.put("name",dateOfStud.getName());
		System.out.println(dateOfStud.getName());
		aStudent.put("id", dateOfStud.getId());
		aStudent.put("ScoresList", dateOfStud.getList());
		out.println(aStudent);
		out.println("============================================================");
		out.flush();
	}
	
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		System.out.println("===============");
		PrintWriter out=resp.getWriter();
		out.println("<h1>howname</h1>");
		out.println("111111111111111");

		
		
		resp.setContentType("text/html;charset=utf-8");
		resp.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
//        PrintWriter out = resp.getWriter();

		//前端传过来的参数：1.查询对象（0，1表示）2.查询账号:031802444
		//"user"表示对象：学生或者班长，学生为0，班长为1
		//"id"代表账号
		String operation = req.getParameter("operation");//操作对象
		//返回json数据
		
		//如果user是学生，那么返回学生的-->各学科分数(6)，平均分，班级排名百分比，班级排名
		//通过请求对象req的参数查询数据库里面的数据。
		//学生端查询测试
		MyDao md = new MyDao();
		if("1".equals(operation)) {
			String id = req.getParameter("id");
			Student dateOfStud = md.getDateOfStud(id);
			JSONObject aStudent = new JSONObject();
			aStudent.put("name",dateOfStud.getName());
			aStudent.put("id", dateOfStud.getId());
			aStudent.put("ScoresList", dateOfStud.getList());
			out.println(aStudent);
			out.flush();
		}
		
		//班长端查询数据
		if("2".equals(operation)) {
			String cla = req.getParameter("class");
			MyClass mc = md.getSummOfCla(1);
			JSONObject aClass = new JSONObject();
			aClass.put("BasicDate", mc.getSubjList());//每个科目基本数据
			aClass.put("StuScores", mc.getStuList());//学生成绩
			aClass.put("SubjRank", mc.getSubjMap());//学科排名
			out.println(aClass);
			out.flush();
		}
	}
}
