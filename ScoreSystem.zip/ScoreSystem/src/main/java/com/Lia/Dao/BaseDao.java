package com.Lia.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Lia.Util.ConfigManager;

/*
 * BaseDao实现了JDBC的基本功能，作为父类
 */
public class BaseDao {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	//获得链接
	public boolean getConnection() {
		try {
//			System.out.println("----------------");
//			String url = ConfigManager.getInstance().getString("url");
//			String password = ConfigManager.getInstance().getString("password");
//			String username = ConfigManager.getInstance().getString("username");
			String url  = "jdbc:mysql://localhost:3306/scoresrecord?serverTimezone=UTC&useSSL=false";
			String password = "1234";
			String username = "root";


			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			conn = DriverManager.getConnection(url,username,password);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	//增删改
	public int executeUpdate(String sql,Object[] params) {
		int updateRows = 0; 
		if(this.getConnection()) {
			try {
				pstmt = conn.prepareStatement(sql);
				for(int i=0;i<params.length;i++) {
					pstmt.setObject(i+1, params[i]);
				}
				updateRows = pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return updateRows;
	}
	
	//查
	public ResultSet executeSql(String sql,Object params[]) {
		
		if(this.getConnection()) {
			try {
				pstmt = conn.prepareStatement(sql);
				for(int i=0;i<params.length;i++) {
					pstmt.setObject(i+1, params[i]);
				}
				//调试信息
//				System.out.println(pstmt);
//				System.out.println("==================");
				rs = pstmt.executeQuery();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return rs;
	}
	
	//释放资源
	public boolean closeResource() {
		if(rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		if(pstmt!=null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		if(conn!=null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
	
	
}
