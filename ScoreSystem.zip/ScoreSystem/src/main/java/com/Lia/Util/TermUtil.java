package com.Lia.Util;

public class TermUtil {
	private static String[] term = {"大一上","大一下","大二上","大二下"};
	public static String getTerm(int i) {
		return term[i];
	}
}

